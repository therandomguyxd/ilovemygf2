# - Load Msg
tellraw @a {text:"\n"}
tellraw @a {text:"-------- Thanks For Using The Set Home Datapack --------", color:green}
tellraw @a {text:"\n", "color":"green"}
tellraw @a [{text:"---------------- Created By Apmaster2 ----------------", color:yellow}]


tellraw @a {text:"\n"}


# - Scoreboard Setup
scoreboard objectives add SetHome trigger
scoreboard objectives add Home trigger
scoreboard objectives add SetHomeX dummy
scoreboard objectives add SetHomeY dummy
scoreboard objectives add SetHomeZ dummy
scoreboard objectives add SetHomeYaw dummy
scoreboard objectives add SetHomePitch dummy
scoreboard objectives add SetHomeDimension dummy