execute store result score @s SetHomeX run data get entity @s Pos[0] 1
execute store result score @s SetHomeY run data get entity @s Pos[1] 1
execute store result score @s SetHomeZ run data get entity @s Pos[2] 1
execute store result score @s SetHomeYaw run data get entity @s Rotation[0] 1
execute store result score @s SetHomePitch run data get entity @s Rotation[1] 1
execute if entity @s[predicate=set_home:in_over_world] run scoreboard players set @s SetHomeDimension 1
execute if entity @s[predicate=set_home:in_nether] run scoreboard players set @s SetHomeDimension 2
execute if entity @s[predicate=set_home:in_end] run scoreboard players set @s SetHomeDimension 3
title @s actionbar {"text":"Home Set!","color":"yellow","bold":true}
particle totem_of_undying ~ ~2 ~ 0.01 0.01 0.01 0.5 50 normal @s
playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1
scoreboard players reset @s SetHome