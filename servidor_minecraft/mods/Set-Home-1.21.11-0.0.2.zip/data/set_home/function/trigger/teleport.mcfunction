execute store result storage sethome:cordinates X int 1 run scoreboard players get @s SetHomeX
execute store result storage sethome:cordinates Y int 1 run scoreboard players get @s SetHomeY
execute store result storage sethome:cordinates Z int 1 run scoreboard players get @s SetHomeZ
execute store result storage sethome:cordinates Yaw int 1 run scoreboard players get @s SetHomeYaw
execute store result storage sethome:cordinates Pitch int 1 run scoreboard players get @s SetHomePitch
execute if entity @s[scores={SetHomeDimension=1}] in overworld run function set_home:teleport_macro with storage sethome:cordinates
execute if entity @s[scores={SetHomeDimension=2}] in the_nether run function set_home:teleport_macro with storage sethome:cordinates
execute if entity @s[scores={SetHomeDimension=3}] in the_end run function set_home:teleport_macro with storage sethome:cordinates
particle totem_of_undying ~ ~2 ~ 0.01 0.01 0.01 0.5 50 normal @s
playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1
title @s actionbar {"text":"Teleported To Home!","color":"yellow","bold":true}
scoreboard players reset @s Home