$tp @s $(X) $(Y) $(Z) $(Yaw) $(Pitch)
$execute positioned $(X) $(Y) $(Z) run particle totem_of_undying ~ ~2 ~ 0.01 0.01 0.01 0.5 50 normal @s
$execute positioned $(X) $(Y) $(Z) run playsound entity.experience_orb.pickup master @s ~ ~ ~ 1 1