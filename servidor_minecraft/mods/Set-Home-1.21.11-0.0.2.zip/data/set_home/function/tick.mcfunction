# - Sethome
execute as @a[scores={SetHome=1..}] at @s run function set_home:trigger/sethome

# - Teleport
execute as @a[scores={Home=1..}] at @s run function set_home:trigger/teleport

# - Enable Triggers
scoreboard players enable @a SetHome
scoreboard players enable @a Home

